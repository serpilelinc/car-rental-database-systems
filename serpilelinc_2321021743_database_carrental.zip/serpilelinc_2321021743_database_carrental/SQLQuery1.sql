USE [master]
GO
/****** Object:  Database [CarRentalTrackingDB]    Script Date: 15.12.2025 19:10:38 ******/
CREATE DATABASE [CarRentalTrackingDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'CarRentalTrackingDB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL17.MSSQLSERVER\MSSQL\DATA\CarRentalTrackingDB.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'CarRentalTrackingDB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL17.MSSQLSERVER\MSSQL\DATA\CarRentalTrackingDB_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [CarRentalTrackingDB] SET COMPATIBILITY_LEVEL = 170
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [CarRentalTrackingDB].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [CarRentalTrackingDB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET ARITHABORT OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [CarRentalTrackingDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [CarRentalTrackingDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET  ENABLE_BROKER 
GO
ALTER DATABASE [CarRentalTrackingDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [CarRentalTrackingDB] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET RECOVERY FULL 
GO
ALTER DATABASE [CarRentalTrackingDB] SET  MULTI_USER 
GO
ALTER DATABASE [CarRentalTrackingDB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [CarRentalTrackingDB] SET DB_CHAINING OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [CarRentalTrackingDB] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [CarRentalTrackingDB] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [CarRentalTrackingDB] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [CarRentalTrackingDB] SET OPTIMIZED_LOCKING = OFF 
GO
ALTER DATABASE [CarRentalTrackingDB] SET QUERY_STORE = ON
GO
ALTER DATABASE [CarRentalTrackingDB] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [CarRentalTrackingDB]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_CalculateRentalTotal]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- 4. FONKS�YON VE PROSED�RLER
-- =============================================

CREATE FUNCTION [dbo].[fn_CalculateRentalTotal]
(
    @CarID INT,
    @StartDate DATETIME,
    @EndDate DATETIME
)
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @TotalCost DECIMAL(10, 2);
    DECLARE @DailyRate DECIMAL(10, 2);
    DECLARE @Days INT;
    SELECT @DailyRate = DailyRate FROM Cars WHERE CarID = @CarID;
    SET @Days = DATEDIFF(DAY, @StartDate, @EndDate);
    IF @Days < 1 SET @Days = 1;
    SET @TotalCost = @DailyRate * @Days;
    RETURN @TotalCost;
END
GO
/****** Object:  Table [dbo].[CarBrands]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CarBrands](
	[BrandID] [int] IDENTITY(1,1) NOT NULL,
	[BrandName] [nvarchar](100) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[BrandID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CarMaintenance]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CarMaintenance](
	[MaintenanceID] [int] IDENTITY(1,1) NOT NULL,
	[CarID] [int] NOT NULL,
	[MechanicID] [int] NULL,
	[MaintenanceType] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](500) NULL,
	[Cost] [decimal](10, 2) NULL,
	[MaintenanceDate] [datetime] NOT NULL,
	[NextMaintenanceDate] [datetime] NULL,
	[Status] [nvarchar](50) NULL,
	[CreatedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[MaintenanceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CarModels]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CarModels](
	[ModelID] [int] IDENTITY(1,1) NOT NULL,
	[BrandID] [int] NOT NULL,
	[ModelName] [nvarchar](100) NOT NULL,
	[Year] [int] NOT NULL,
	[FuelType] [nvarchar](50) NULL,
	[Transmission] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[ModelID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Cars]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Cars](
	[CarID] [int] IDENTITY(1,1) NOT NULL,
	[ModelID] [int] NOT NULL,
	[StatusID] [int] NOT NULL,
	[OfficeID] [int] NOT NULL,
	[LicensePlate] [nvarchar](20) NOT NULL,
	[VIN] [nvarchar](50) NOT NULL,
	[Color] [nvarchar](50) NULL,
	[Mileage] [int] NULL,
	[DailyRate] [decimal](10, 2) NOT NULL,
	[PurchaseDate] [date] NULL,
	[LastServiceDate] [date] NULL,
	[NextServiceDate] [date] NULL,
	[CreatedAt] [datetime] NULL,
	[UpdatedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[CarID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CarStatus]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CarStatus](
	[StatusID] [int] IDENTITY(1,1) NOT NULL,
	[StatusName] [nvarchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[StatusID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[InsurancePolicies]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InsurancePolicies](
	[PolicyID] [int] IDENTITY(1,1) NOT NULL,
	[CarID] [int] NOT NULL,
	[PolicyNumber] [nvarchar](100) NOT NULL,
	[Provider] [nvarchar](100) NOT NULL,
	[CoverageType] [nvarchar](100) NULL,
	[PremiumAmount] [decimal](10, 2) NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NOT NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[PolicyID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MaintenanceTypes]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MaintenanceTypes](
	[TypeID] [int] IDENTITY(1,1) NOT NULL,
	[TypeName] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[TypeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Mechanics]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Mechanics](
	[MechanicID] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [nvarchar](100) NOT NULL,
	[LastName] [nvarchar](100) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[MechanicID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Offices]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Offices](
	[OfficeID] [int] IDENTITY(1,1) NOT NULL,
	[OfficeName] [nvarchar](100) NOT NULL,
	[Address] [nvarchar](255) NULL,
	[City] [nvarchar](100) NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[OfficeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PaymentMethods]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PaymentMethods](
	[MethodID] [int] IDENTITY(1,1) NOT NULL,
	[MethodName] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[MethodID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Payments]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Payments](
	[PaymentID] [int] IDENTITY(1,1) NOT NULL,
	[RentalID] [int] NOT NULL,
	[Amount] [decimal](10, 2) NOT NULL,
	[PaymentMethod] [nvarchar](50) NULL,
	[PaymentStatus] [nvarchar](50) NULL,
	[TransactionID] [nvarchar](100) NULL,
	[PaymentDate] [datetime] NULL,
	[CreatedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[PaymentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Rentals]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Rentals](
	[RentalID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL,
	[CarID] [int] NOT NULL,
	[OfficeID] [int] NOT NULL,
	[StartDate] [datetime] NOT NULL,
	[EndDate] [datetime] NOT NULL,
	[ActualReturnDate] [datetime] NULL,
	[TotalCost] [decimal](10, 2) NULL,
	[Status] [nvarchar](50) NULL,
	[Notes] [nvarchar](500) NULL,
	[CreatedAt] [datetime] NULL,
	[UpdatedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[RentalID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Roles]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Roles](
	[RoleID] [int] IDENTITY(1,1) NOT NULL,
	[RoleName] [nvarchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[RoleID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserLogs]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserLogs](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL,
	[Action] [nvarchar](255) NOT NULL,
	[IPAddress] [nvarchar](50) NULL,
	[LogTime] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Users]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[UserID] [int] IDENTITY(1,1) NOT NULL,
	[RoleID] [int] NOT NULL,
	[FirstName] [nvarchar](100) NOT NULL,
	[LastName] [nvarchar](100) NOT NULL,
	[Email] [nvarchar](100) NOT NULL,
	[PasswordHash] [nvarchar](255) NOT NULL,
	[PhoneNumber] [nvarchar](20) NULL,
	[Address] [nvarchar](255) NULL,
	[LicenseNumber] [nvarchar](50) NULL,
	[IsActive] [bit] NULL,
	[CreatedAt] [datetime] NULL,
	[UpdatedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[CarBrands] ON 

INSERT [dbo].[CarBrands] ([BrandID], [BrandName]) VALUES (4, N'BMW')
INSERT [dbo].[CarBrands] ([BrandID], [BrandName]) VALUES (3, N'Ford')
INSERT [dbo].[CarBrands] ([BrandID], [BrandName]) VALUES (2, N'Honda')
INSERT [dbo].[CarBrands] ([BrandID], [BrandName]) VALUES (5, N'Mercedes-Benz')
INSERT [dbo].[CarBrands] ([BrandID], [BrandName]) VALUES (1, N'Toyota')
SET IDENTITY_INSERT [dbo].[CarBrands] OFF
GO
SET IDENTITY_INSERT [dbo].[CarMaintenance] ON 

INSERT [dbo].[CarMaintenance] ([MaintenanceID], [CarID], [MechanicID], [MaintenanceType], [Description], [Cost], [MaintenanceDate], [NextMaintenanceDate], [Status], [CreatedAt]) VALUES (1, 1, 1, N'Oil Change', N'Regular oil change and filter replacement', CAST(75.00 AS Decimal(10, 2)), CAST(N'2024-11-01T00:00:00.000' AS DateTime), CAST(N'2025-02-01T00:00:00.000' AS DateTime), N'Completed', CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[CarMaintenance] ([MaintenanceID], [CarID], [MechanicID], [MaintenanceType], [Description], [Cost], [MaintenanceDate], [NextMaintenanceDate], [Status], [CreatedAt]) VALUES (2, 2, 2, N'Tire Rotation', N'Rotated all four tires', CAST(50.00 AS Decimal(10, 2)), CAST(N'2024-10-15T00:00:00.000' AS DateTime), CAST(N'2025-01-15T00:00:00.000' AS DateTime), N'Completed', CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[CarMaintenance] ([MaintenanceID], [CarID], [MechanicID], [MaintenanceType], [Description], [Cost], [MaintenanceDate], [NextMaintenanceDate], [Status], [CreatedAt]) VALUES (3, 3, 1, N'Brake Inspection', N'Checked brake pads and fluid', CAST(100.00 AS Decimal(10, 2)), CAST(N'2024-11-20T00:00:00.000' AS DateTime), CAST(N'2025-02-20T00:00:00.000' AS DateTime), N'Completed', CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[CarMaintenance] ([MaintenanceID], [CarID], [MechanicID], [MaintenanceType], [Description], [Cost], [MaintenanceDate], [NextMaintenanceDate], [Status], [CreatedAt]) VALUES (4, 4, 2, N'Oil Change', N'Regular oil change', CAST(75.00 AS Decimal(10, 2)), CAST(N'2024-11-25T00:00:00.000' AS DateTime), CAST(N'2025-02-25T00:00:00.000' AS DateTime), N'Completed', CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[CarMaintenance] ([MaintenanceID], [CarID], [MechanicID], [MaintenanceType], [Description], [Cost], [MaintenanceDate], [NextMaintenanceDate], [Status], [CreatedAt]) VALUES (5, 5, 1, N'Full Service', N'Complete service and inspection', CAST(250.00 AS Decimal(10, 2)), CAST(N'2024-11-10T00:00:00.000' AS DateTime), CAST(N'2025-02-10T00:00:00.000' AS DateTime), N'Completed', CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[CarMaintenance] ([MaintenanceID], [CarID], [MechanicID], [MaintenanceType], [Description], [Cost], [MaintenanceDate], [NextMaintenanceDate], [Status], [CreatedAt]) VALUES (6, 6, 2, N'S�v� De�i�imi', N's', CAST(1200.00 AS Decimal(10, 2)), CAST(N'2025-01-01T00:00:00.000' AS DateTime), CAST(N'2025-11-01T00:00:00.000' AS DateTime), N'Completed', CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[CarMaintenance] ([MaintenanceID], [CarID], [MechanicID], [MaintenanceType], [Description], [Cost], [MaintenanceDate], [NextMaintenanceDate], [Status], [CreatedAt]) VALUES (7, 10, 1, N'Engine Check', N'sada', CAST(324.00 AS Decimal(10, 2)), CAST(N'2025-01-01T00:00:00.000' AS DateTime), CAST(N'2026-01-01T00:00:00.000' AS DateTime), N'Completed', CAST(N'2025-12-13T16:19:14.623' AS DateTime))
SET IDENTITY_INSERT [dbo].[CarMaintenance] OFF
GO
SET IDENTITY_INSERT [dbo].[CarModels] ON 

INSERT [dbo].[CarModels] ([ModelID], [BrandID], [ModelName], [Year], [FuelType], [Transmission]) VALUES (1, 1, N'Camry', 2023, N'Gasoline', N'Automatic')
INSERT [dbo].[CarModels] ([ModelID], [BrandID], [ModelName], [Year], [FuelType], [Transmission]) VALUES (2, 1, N'RAV4', 2023, N'Hybrid', N'Automatic')
INSERT [dbo].[CarModels] ([ModelID], [BrandID], [ModelName], [Year], [FuelType], [Transmission]) VALUES (3, 2, N'Accord', 2023, N'Gasoline', N'Automatic')
INSERT [dbo].[CarModels] ([ModelID], [BrandID], [ModelName], [Year], [FuelType], [Transmission]) VALUES (4, 3, N'Mustang', 2023, N'Gasoline', N'Manual')
INSERT [dbo].[CarModels] ([ModelID], [BrandID], [ModelName], [Year], [FuelType], [Transmission]) VALUES (5, 4, N'X5', 2023, N'Diesel', N'Automatic')
INSERT [dbo].[CarModels] ([ModelID], [BrandID], [ModelName], [Year], [FuelType], [Transmission]) VALUES (6, 5, N'E-Class', 2023, N'Gasoline', N'Automatic')
SET IDENTITY_INSERT [dbo].[CarModels] OFF
GO
SET IDENTITY_INSERT [dbo].[Cars] ON 

INSERT [dbo].[Cars] ([CarID], [ModelID], [StatusID], [OfficeID], [LicensePlate], [VIN], [Color], [Mileage], [DailyRate], [PurchaseDate], [LastServiceDate], [NextServiceDate], [CreatedAt], [UpdatedAt]) VALUES (1, 1, 1, 1, N'CAL-2023-001', N'1HGCM82633A123456', N'Silver', 15000, CAST(65.00 AS Decimal(10, 2)), CAST(N'2023-01-15' AS Date), CAST(N'2024-11-01' AS Date), NULL, CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-14T16:38:24.737' AS DateTime))
INSERT [dbo].[Cars] ([CarID], [ModelID], [StatusID], [OfficeID], [LicensePlate], [VIN], [Color], [Mileage], [DailyRate], [PurchaseDate], [LastServiceDate], [NextServiceDate], [CreatedAt], [UpdatedAt]) VALUES (2, 2, 1, 1, N'CAL-2023-002', N'2T3ZFREV9KW123789', N'Blue', 12000, CAST(75.00 AS Decimal(10, 2)), CAST(N'2023-02-20' AS Date), CAST(N'2024-10-15' AS Date), CAST(N'2025-01-15' AS Date), CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-14T16:38:24.737' AS DateTime))
INSERT [dbo].[Cars] ([CarID], [ModelID], [StatusID], [OfficeID], [LicensePlate], [VIN], [Color], [Mileage], [DailyRate], [PurchaseDate], [LastServiceDate], [NextServiceDate], [CreatedAt], [UpdatedAt]) VALUES (3, 3, 1, 2, N'CAL-2023-003', N'1HGCV1F47MA123456', N'Red', 8000, CAST(70.00 AS Decimal(10, 2)), CAST(N'2023-03-10' AS Date), CAST(N'2024-11-20' AS Date), CAST(N'2025-02-20' AS Date), CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-14T16:38:24.737' AS DateTime))
INSERT [dbo].[Cars] ([CarID], [ModelID], [StatusID], [OfficeID], [LicensePlate], [VIN], [Color], [Mileage], [DailyRate], [PurchaseDate], [LastServiceDate], [NextServiceDate], [CreatedAt], [UpdatedAt]) VALUES (4, 4, 2, 2, N'CAL-2023-004', N'1FA6P8CF5J5123456', N'Yellow', 5000, CAST(95.00 AS Decimal(10, 2)), CAST(N'2023-04-05' AS Date), CAST(N'2024-11-25' AS Date), CAST(N'2025-02-25' AS Date), CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[Cars] ([CarID], [ModelID], [StatusID], [OfficeID], [LicensePlate], [VIN], [Color], [Mileage], [DailyRate], [PurchaseDate], [LastServiceDate], [NextServiceDate], [CreatedAt], [UpdatedAt]) VALUES (5, 5, 1, 3, N'NY-2023-001', N'5UXCR6C03L9123456', N'Black', 20000, CAST(120.00 AS Decimal(10, 2)), CAST(N'2023-05-01' AS Date), CAST(N'2024-11-10' AS Date), CAST(N'2025-02-10' AS Date), CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-14T16:38:24.737' AS DateTime))
INSERT [dbo].[Cars] ([CarID], [ModelID], [StatusID], [OfficeID], [LicensePlate], [VIN], [Color], [Mileage], [DailyRate], [PurchaseDate], [LastServiceDate], [NextServiceDate], [CreatedAt], [UpdatedAt]) VALUES (6, 6, 1, 3, N'38sd022', N'v�n', N'pink', 35000, CAST(200.00 AS Decimal(10, 2)), CAST(N'2025-12-11' AS Date), NULL, CAST(N'2026-03-11' AS Date), CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-14T16:38:24.737' AS DateTime))
INSERT [dbo].[Cars] ([CarID], [ModelID], [StatusID], [OfficeID], [LicensePlate], [VIN], [Color], [Mileage], [DailyRate], [PurchaseDate], [LastServiceDate], [NextServiceDate], [CreatedAt], [UpdatedAt]) VALUES (7, 3, 1, 1, N'a', N'a', N'a', 1, CAST(222.00 AS Decimal(10, 2)), CAST(N'2025-12-11' AS Date), NULL, CAST(N'2026-03-11' AS Date), CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-14T16:38:24.737' AS DateTime))
INSERT [dbo].[Cars] ([CarID], [ModelID], [StatusID], [OfficeID], [LicensePlate], [VIN], [Color], [Mileage], [DailyRate], [PurchaseDate], [LastServiceDate], [NextServiceDate], [CreatedAt], [UpdatedAt]) VALUES (8, 1, 1, 1, N'b', N'b', N'b', 2, CAST(333.00 AS Decimal(10, 2)), NULL, NULL, NULL, CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-14T16:38:24.737' AS DateTime))
INSERT [dbo].[Cars] ([CarID], [ModelID], [StatusID], [OfficeID], [LicensePlate], [VIN], [Color], [Mileage], [DailyRate], [PurchaseDate], [LastServiceDate], [NextServiceDate], [CreatedAt], [UpdatedAt]) VALUES (10, 1, 1, 3, N're', N'ewr', N'wer', 324, CAST(234.00 AS Decimal(10, 2)), CAST(N'2025-12-12' AS Date), NULL, CAST(N'2026-03-12' AS Date), CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-14T16:38:24.737' AS DateTime))
SET IDENTITY_INSERT [dbo].[Cars] OFF
GO
SET IDENTITY_INSERT [dbo].[CarStatus] ON 

INSERT [dbo].[CarStatus] ([StatusID], [StatusName]) VALUES (1, N'Available')
INSERT [dbo].[CarStatus] ([StatusID], [StatusName]) VALUES (4, N'Damaged')
INSERT [dbo].[CarStatus] ([StatusID], [StatusName]) VALUES (3, N'Maintenance')
INSERT [dbo].[CarStatus] ([StatusID], [StatusName]) VALUES (2, N'Rented')
INSERT [dbo].[CarStatus] ([StatusID], [StatusName]) VALUES (5, N'Reserved')
SET IDENTITY_INSERT [dbo].[CarStatus] OFF
GO
SET IDENTITY_INSERT [dbo].[InsurancePolicies] ON 

INSERT [dbo].[InsurancePolicies] ([PolicyID], [CarID], [PolicyNumber], [Provider], [CoverageType], [PremiumAmount], [StartDate], [EndDate], [IsActive]) VALUES (1, 1, N'POL-2023-001', N'State Farm', N'Comprehensive', CAST(150.00 AS Decimal(10, 2)), CAST(N'2023-01-15' AS Date), CAST(N'2024-01-15' AS Date), 1)
INSERT [dbo].[InsurancePolicies] ([PolicyID], [CarID], [PolicyNumber], [Provider], [CoverageType], [PremiumAmount], [StartDate], [EndDate], [IsActive]) VALUES (2, 2, N'POL-2023-002', N'Geico', N'Comprehensive', CAST(160.00 AS Decimal(10, 2)), CAST(N'2023-02-20' AS Date), CAST(N'2024-02-20' AS Date), 1)
INSERT [dbo].[InsurancePolicies] ([PolicyID], [CarID], [PolicyNumber], [Provider], [CoverageType], [PremiumAmount], [StartDate], [EndDate], [IsActive]) VALUES (3, 3, N'POL-2023-003', N'Progressive', N'Liability', CAST(120.00 AS Decimal(10, 2)), CAST(N'2023-03-10' AS Date), CAST(N'2024-03-10' AS Date), 1)
INSERT [dbo].[InsurancePolicies] ([PolicyID], [CarID], [PolicyNumber], [Provider], [CoverageType], [PremiumAmount], [StartDate], [EndDate], [IsActive]) VALUES (4, 4, N'POL-2023-004', N'Allstate', N'Comprehensive', CAST(180.00 AS Decimal(10, 2)), CAST(N'2023-04-05' AS Date), CAST(N'2024-04-05' AS Date), 1)
INSERT [dbo].[InsurancePolicies] ([PolicyID], [CarID], [PolicyNumber], [Provider], [CoverageType], [PremiumAmount], [StartDate], [EndDate], [IsActive]) VALUES (5, 5, N'POL-2023-005', N'Liberty Mutual', N'Premium', CAST(200.00 AS Decimal(10, 2)), CAST(N'2023-05-01' AS Date), CAST(N'2024-05-01' AS Date), 1)
INSERT [dbo].[InsurancePolicies] ([PolicyID], [CarID], [PolicyNumber], [Provider], [CoverageType], [PremiumAmount], [StartDate], [EndDate], [IsActive]) VALUES (6, 6, N'331', N'fsm', N'prem�um', CAST(500.00 AS Decimal(10, 2)), CAST(N'2025-01-01' AS Date), CAST(N'2027-02-02' AS Date), 1)
SET IDENTITY_INSERT [dbo].[InsurancePolicies] OFF
GO
SET IDENTITY_INSERT [dbo].[MaintenanceTypes] ON 

INSERT [dbo].[MaintenanceTypes] ([TypeID], [TypeName], [Description]) VALUES (1, N'Oil Change', N'Regular oil change')
INSERT [dbo].[MaintenanceTypes] ([TypeID], [TypeName], [Description]) VALUES (2, N'Brake Inspection', N'Brake pads/fluids check')
INSERT [dbo].[MaintenanceTypes] ([TypeID], [TypeName], [Description]) VALUES (3, N'Tire Rotation', N'Rotate tires')
INSERT [dbo].[MaintenanceTypes] ([TypeID], [TypeName], [Description]) VALUES (4, N'Full Service', N'Comprehensive service')
INSERT [dbo].[MaintenanceTypes] ([TypeID], [TypeName], [Description]) VALUES (5, N'Engine Check', N'Engine diagnostics')
INSERT [dbo].[MaintenanceTypes] ([TypeID], [TypeName], [Description]) VALUES (6, N'S�v� De�i�imi', N'Genel s�v� kontrol�')
SET IDENTITY_INSERT [dbo].[MaintenanceTypes] OFF
GO
SET IDENTITY_INSERT [dbo].[Mechanics] ON 

INSERT [dbo].[Mechanics] ([MechanicID], [FirstName], [LastName]) VALUES (1, N'Carlos', N'Rodriguez')
INSERT [dbo].[Mechanics] ([MechanicID], [FirstName], [LastName]) VALUES (2, N'Maria', N'Garcia')
SET IDENTITY_INSERT [dbo].[Mechanics] OFF
GO
SET IDENTITY_INSERT [dbo].[Offices] ON 

INSERT [dbo].[Offices] ([OfficeID], [OfficeName], [Address], [City], [IsActive]) VALUES (1, N'Downtown LA Office', N'500 S Grand Ave', N'Los Angeles', 1)
INSERT [dbo].[Offices] ([OfficeID], [OfficeName], [Address], [City], [IsActive]) VALUES (2, N'San Francisco Airport', N'780 McDonnell Rd', N'San Francisco', 1)
INSERT [dbo].[Offices] ([OfficeID], [OfficeName], [Address], [City], [IsActive]) VALUES (3, N'New York Manhattan', N'350 5th Ave', N'New York', 1)
SET IDENTITY_INSERT [dbo].[Offices] OFF
GO
SET IDENTITY_INSERT [dbo].[PaymentMethods] ON 

INSERT [dbo].[PaymentMethods] ([MethodID], [MethodName], [Description]) VALUES (1, N'Credit Card', N'Visa/Master/Amex')
INSERT [dbo].[PaymentMethods] ([MethodID], [MethodName], [Description]) VALUES (2, N'Debit Card', N'Bank debit')
INSERT [dbo].[PaymentMethods] ([MethodID], [MethodName], [Description]) VALUES (3, N'Cash', N'Cash payment')
INSERT [dbo].[PaymentMethods] ([MethodID], [MethodName], [Description]) VALUES (4, N'Wire Transfer', N'Bank transfer')
SET IDENTITY_INSERT [dbo].[PaymentMethods] OFF
GO
SET IDENTITY_INSERT [dbo].[Payments] ON 

INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (1, 1, CAST(375.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'TXN-20241201-001', CAST(N'2025-12-09T00:00:00.000' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (2, 2, CAST(475.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'TXN-20241202-002', CAST(N'2025-12-10T00:00:00.000' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (3, 3, CAST(325.00 AS Decimal(10, 2)), N'Debit Card', N'Completed', N'TXN-20231125-003', CAST(N'2025-11-26T00:00:00.000' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (4, 4, CAST(210.00 AS Decimal(10, 2)), N'Cash', N'Completed', N'TXN-20231120-004', CAST(N'2025-11-21T00:00:00.000' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (5, 5, CAST(600.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'TXN-20231110-005', CAST(N'2025-11-11T00:00:00.000' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (6, 10, CAST(222.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'AUTO-10', CAST(N'2025-12-11T00:00:00.000' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (7, 11, CAST(333.00 AS Decimal(10, 2)), N'Cash', N'Completed', N'AUTO-11', CAST(N'2025-12-11T00:00:00.000' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (8, 12, CAST(234.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'AUTO-12', CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (9, 13, CAST(120.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'AUTO-13', CAST(N'2025-12-13T16:20:18.240' AS DateTime), CAST(N'2025-12-13T16:20:18.240' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (10, 14, CAST(240.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'AUTO-14', CAST(N'2025-12-13T16:21:03.717' AS DateTime), CAST(N'2025-12-13T16:21:03.717' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (11, 15, CAST(120.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'AUTO-15', CAST(N'2025-12-13T16:21:38.180' AS DateTime), CAST(N'2025-12-13T16:21:38.180' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (12, 16, CAST(70.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'AUTO-16', CAST(N'2025-12-13T16:55:39.937' AS DateTime), CAST(N'2025-12-13T16:55:39.937' AS DateTime))
INSERT [dbo].[Payments] ([PaymentID], [RentalID], [Amount], [PaymentMethod], [PaymentStatus], [TransactionID], [PaymentDate], [CreatedAt]) VALUES (13, 17, CAST(222.00 AS Decimal(10, 2)), N'Credit Card', N'Completed', N'AUTO-17', CAST(N'2025-12-13T16:56:33.340' AS DateTime), CAST(N'2025-12-13T16:56:33.340' AS DateTime))
SET IDENTITY_INSERT [dbo].[Payments] OFF
GO
SET IDENTITY_INSERT [dbo].[Rentals] ON 

INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (1, 3, 2, 1, CAST(N'2025-12-09T00:00:00.000' AS DateTime), CAST(N'2025-12-14T00:00:00.000' AS DateTime), CAST(N'2025-12-14T00:00:00.000' AS DateTime), CAST(375.00 AS Decimal(10, 2)), N'Completed', N'Customer requested GPS tracking', CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-14T16:37:02.880' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (2, 4, 4, 2, CAST(N'2025-12-10T00:00:00.000' AS DateTime), CAST(N'2025-12-15T00:00:00.000' AS DateTime), NULL, CAST(475.00 AS Decimal(10, 2)), N'Active', N'Premium insurance added', CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (3, 3, 1, 1, CAST(N'2025-11-26T00:00:00.000' AS DateTime), CAST(N'2025-12-01T00:00:00.000' AS DateTime), CAST(N'2025-12-01T00:00:00.000' AS DateTime), CAST(325.00 AS Decimal(10, 2)), N'Completed', N'Returned on time', CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (4, 4, 3, 2, CAST(N'2025-11-21T00:00:00.000' AS DateTime), CAST(N'2025-11-24T00:00:00.000' AS DateTime), CAST(N'2025-11-24T00:00:00.000' AS DateTime), CAST(210.00 AS Decimal(10, 2)), N'Completed', N'No issues', CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (5, 3, 5, 3, CAST(N'2025-11-11T00:00:00.000' AS DateTime), CAST(N'2025-11-16T00:00:00.000' AS DateTime), CAST(N'2025-11-16T00:00:00.000' AS DateTime), CAST(600.00 AS Decimal(10, 2)), N'Completed', N'Business trip', CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:14.627' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (6, 3, 1, 1, CAST(N'2025-12-11T00:00:00.000' AS DateTime), CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(65.00 AS Decimal(10, 2)), N'Completed', NULL, CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:59.237' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (7, 3, 3, 1, CAST(N'2025-12-11T00:00:00.000' AS DateTime), CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(70.00 AS Decimal(10, 2)), N'Completed', NULL, CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:59.237' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (8, 6, 6, 1, CAST(N'2025-12-11T00:00:00.000' AS DateTime), CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(200.00 AS Decimal(10, 2)), N'Completed', NULL, CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:59.237' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (9, 6, 5, 1, CAST(N'2025-12-09T00:00:00.000' AS DateTime), CAST(N'2025-12-10T00:00:00.000' AS DateTime), CAST(N'2025-12-10T00:00:00.000' AS DateTime), CAST(120.00 AS Decimal(10, 2)), N'Completed', NULL, CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:59.237' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (10, 6, 7, 1, CAST(N'2025-12-09T00:00:00.000' AS DateTime), CAST(N'2025-12-10T00:00:00.000' AS DateTime), CAST(N'2025-12-10T00:00:00.000' AS DateTime), CAST(222.00 AS Decimal(10, 2)), N'Completed', NULL, CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:59.237' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (11, 6, 8, 1, CAST(N'2025-12-11T00:00:00.000' AS DateTime), CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(333.00 AS Decimal(10, 2)), N'Completed', NULL, CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:59.237' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (12, 6, 10, 1, CAST(N'2025-12-12T00:00:00.000' AS DateTime), CAST(N'2025-12-13T00:00:00.000' AS DateTime), CAST(N'2025-12-13T00:00:00.000' AS DateTime), CAST(234.00 AS Decimal(10, 2)), N'Completed', NULL, CAST(N'2025-12-13T16:19:14.627' AS DateTime), CAST(N'2025-12-13T16:19:59.237' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (13, 7, 5, 1, CAST(N'2025-12-13T16:19:59.190' AS DateTime), CAST(N'2025-12-15T00:00:00.000' AS DateTime), NULL, CAST(240.00 AS Decimal(10, 2)), N'Active', NULL, CAST(N'2025-12-13T16:20:18.230' AS DateTime), CAST(N'2025-12-13T16:20:18.230' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (14, 6, 5, 1, CAST(N'2025-12-16T00:00:00.000' AS DateTime), CAST(N'2025-12-18T00:00:00.000' AS DateTime), NULL, CAST(240.00 AS Decimal(10, 2)), N'Active', NULL, CAST(N'2025-12-13T16:21:03.713' AS DateTime), CAST(N'2025-12-13T16:21:03.713' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (15, 7, 5, 1, CAST(N'2025-12-19T00:00:00.000' AS DateTime), CAST(N'2025-12-20T00:00:00.000' AS DateTime), NULL, CAST(120.00 AS Decimal(10, 2)), N'Active', NULL, CAST(N'2025-12-13T16:21:38.177' AS DateTime), CAST(N'2025-12-13T16:21:38.177' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (16, 6, 3, 1, CAST(N'2025-12-13T16:55:21.387' AS DateTime), CAST(N'2025-12-15T00:00:00.000' AS DateTime), NULL, CAST(140.00 AS Decimal(10, 2)), N'Active', NULL, CAST(N'2025-12-13T16:55:39.930' AS DateTime), CAST(N'2025-12-13T16:55:39.930' AS DateTime))
INSERT [dbo].[Rentals] ([RentalID], [UserID], [CarID], [OfficeID], [StartDate], [EndDate], [ActualReturnDate], [TotalCost], [Status], [Notes], [CreatedAt], [UpdatedAt]) VALUES (17, 6, 7, 1, CAST(N'2025-12-13T16:56:21.030' AS DateTime), CAST(N'2025-12-15T00:00:00.000' AS DateTime), NULL, CAST(444.00 AS Decimal(10, 2)), N'Active', NULL, CAST(N'2025-12-13T16:56:33.333' AS DateTime), CAST(N'2025-12-13T16:56:33.333' AS DateTime))
SET IDENTITY_INSERT [dbo].[Rentals] OFF
GO
SET IDENTITY_INSERT [dbo].[Roles] ON 

INSERT [dbo].[Roles] ([RoleID], [RoleName]) VALUES (1, N'Admin')
INSERT [dbo].[Roles] ([RoleID], [RoleName]) VALUES (2, N'Customer')
INSERT [dbo].[Roles] ([RoleID], [RoleName]) VALUES (3, N'Manager')
INSERT [dbo].[Roles] ([RoleID], [RoleName]) VALUES (4, N'Support')
SET IDENTITY_INSERT [dbo].[Roles] OFF
GO
SET IDENTITY_INSERT [dbo].[UserLogs] ON 

INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (1, 1, N'Login', N'192.168.1.100', CAST(N'2025-12-11T22:30:24.000' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (2, 2, N'Login', N'192.168.1.101', CAST(N'2025-12-11T22:30:24.000' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (3, 3, N'Login', N'192.168.1.102', CAST(N'2025-12-11T22:30:24.000' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (4, 4, N'Login', N'192.168.1.103', CAST(N'2025-12-11T22:30:24.000' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (5, 3, N'Create Rental', N'192.168.1.102', CAST(N'2025-12-11T22:30:24.000' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (6, 4, N'Create Rental', N'192.168.1.103', CAST(N'2025-12-11T22:30:24.000' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (7, 7, N'Customer Created', N'Registration Panel', CAST(N'2025-12-13T16:19:59.073' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (8, 6, N'Login', N'Application', CAST(N'2025-12-13T16:20:34.400' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (9, 7, N'Login', N'Application', CAST(N'2025-12-13T16:21:19.667' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (10, 1, N'Login', N'Application', CAST(N'2025-12-13T16:21:57.937' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (11, 1, N'Login', N'Application', CAST(N'2025-12-13T16:28:32.720' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (12, 1, N'Login', N'Application', CAST(N'2025-12-13T16:53:56.797' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (13, 6, N'Login', N'Application', CAST(N'2025-12-13T16:55:21.357' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (14, 6, N'Login', N'Application', CAST(N'2025-12-13T16:56:20.987' AS DateTime))
INSERT [dbo].[UserLogs] ([LogID], [UserID], [Action], [IPAddress], [LogTime]) VALUES (15, 1, N'Login', N'Application', CAST(N'2025-12-14T16:37:02.700' AS DateTime))
SET IDENTITY_INSERT [dbo].[UserLogs] OFF
GO
SET IDENTITY_INSERT [dbo].[Users] ON 

INSERT [dbo].[Users] ([UserID], [RoleID], [FirstName], [LastName], [Email], [PasswordHash], [PhoneNumber], [Address], [LicenseNumber], [IsActive], [CreatedAt], [UpdatedAt]) VALUES (1, 1, N'John', N'Administrator', N'admin@carrental.com', N'hashed_admin123', N'555-0001', N'100 Admin St, New York', N'ADM001', 1, CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[Users] ([UserID], [RoleID], [FirstName], [LastName], [Email], [PasswordHash], [PhoneNumber], [Address], [LicenseNumber], [IsActive], [CreatedAt], [UpdatedAt]) VALUES (2, 1, N'Sarah', N'Manager', N'sarah.manager@carrental.com', N'hashed_admin123', N'555-0002', N'200 Manager Ave, New York', N'ADM002', 1, CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[Users] ([UserID], [RoleID], [FirstName], [LastName], [Email], [PasswordHash], [PhoneNumber], [Address], [LicenseNumber], [IsActive], [CreatedAt], [UpdatedAt]) VALUES (3, 2, N'Mike', N'Johnson', N'mike.johnson@email.com', N'hashed_customer123', N'555-1001', N'123 Main St, Los Angeles', N'DL123456', 1, CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[Users] ([UserID], [RoleID], [FirstName], [LastName], [Email], [PasswordHash], [PhoneNumber], [Address], [LicenseNumber], [IsActive], [CreatedAt], [UpdatedAt]) VALUES (4, 2, N'Emily', N'Davis', N'emily.davis@email.com', N'hashed_customer123', N'555-1002', N'456 Oak Ave, San Francisco', N'DL789012', 1, CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[Users] ([UserID], [RoleID], [FirstName], [LastName], [Email], [PasswordHash], [PhoneNumber], [Address], [LicenseNumber], [IsActive], [CreatedAt], [UpdatedAt]) VALUES (5, 2, N'Test', N'Kullan�c�', N'test.kullanici@example.com', N'hashed_test123', N'555-9999', N'Test Adresi', N'TEST123456', 1, CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[Users] ([UserID], [RoleID], [FirstName], [LastName], [Email], [PasswordHash], [PhoneNumber], [Address], [LicenseNumber], [IsActive], [CreatedAt], [UpdatedAt]) VALUES (6, 2, N'esmanur', N'oru�', N'esmanur@gmail.com', N'hashed_143628', N'0555', N'ka��thane', N'2005', 1, CAST(N'2025-12-13T16:19:14.623' AS DateTime), CAST(N'2025-12-13T16:19:14.623' AS DateTime))
INSERT [dbo].[Users] ([UserID], [RoleID], [FirstName], [LastName], [Email], [PasswordHash], [PhoneNumber], [Address], [LicenseNumber], [IsActive], [CreatedAt], [UpdatedAt]) VALUES (7, 2, N'samet', N'beluk', N'sam@gmail.com', N'hashed_143628', N'123', N'123', N'159', 1, CAST(N'2025-12-13T16:19:59.073' AS DateTime), CAST(N'2025-12-13T16:19:59.073' AS DateTime))
SET IDENTITY_INSERT [dbo].[Users] OFF
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__CarBrand__2206CE9BE43F9E94]    Script Date: 15.12.2025 19:10:38 ******/
ALTER TABLE [dbo].[CarBrands] ADD UNIQUE NONCLUSTERED 
(
	[BrandName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Cars__026BC15C054C9B61]    Script Date: 15.12.2025 19:10:38 ******/
ALTER TABLE [dbo].[Cars] ADD UNIQUE NONCLUSTERED 
(
	[LicensePlate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Cars__C5DF234C4D71C9AD]    Script Date: 15.12.2025 19:10:38 ******/
ALTER TABLE [dbo].[Cars] ADD UNIQUE NONCLUSTERED 
(
	[VIN] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__CarStatu__05E7698AFA8AA55E]    Script Date: 15.12.2025 19:10:38 ******/
ALTER TABLE [dbo].[CarStatus] ADD UNIQUE NONCLUSTERED 
(
	[StatusName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Insuranc__46DA0157769ACCA8]    Script Date: 15.12.2025 19:10:38 ******/
ALTER TABLE [dbo].[InsurancePolicies] ADD UNIQUE NONCLUSTERED 
(
	[PolicyNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Maintena__D4E7DFA8123DC925]    Script Date: 15.12.2025 19:10:38 ******/
ALTER TABLE [dbo].[MaintenanceTypes] ADD UNIQUE NONCLUSTERED 
(
	[TypeName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__PaymentM__218CFB1772D737DE]    Script Date: 15.12.2025 19:10:38 ******/
ALTER TABLE [dbo].[PaymentMethods] ADD UNIQUE NONCLUSTERED 
(
	[MethodName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Roles__8A2B6160EF6DCBE3]    Script Date: 15.12.2025 19:10:38 ******/
ALTER TABLE [dbo].[Roles] ADD UNIQUE NONCLUSTERED 
(
	[RoleName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Users__A9D1053456A1D27B]    Script Date: 15.12.2025 19:10:38 ******/
ALTER TABLE [dbo].[Users] ADD UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CarMaintenance] ADD  DEFAULT ('Scheduled') FOR [Status]
GO
ALTER TABLE [dbo].[CarMaintenance] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Cars] ADD  DEFAULT ((0)) FOR [Mileage]
GO
ALTER TABLE [dbo].[Cars] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Cars] ADD  DEFAULT (getdate()) FOR [UpdatedAt]
GO
ALTER TABLE [dbo].[InsurancePolicies] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Offices] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Payments] ADD  DEFAULT ('Pending') FOR [PaymentStatus]
GO
ALTER TABLE [dbo].[Payments] ADD  DEFAULT (getdate()) FOR [PaymentDate]
GO
ALTER TABLE [dbo].[Payments] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Rentals] ADD  DEFAULT ('Active') FOR [Status]
GO
ALTER TABLE [dbo].[Rentals] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Rentals] ADD  DEFAULT (getdate()) FOR [UpdatedAt]
GO
ALTER TABLE [dbo].[UserLogs] ADD  DEFAULT (getdate()) FOR [LogTime]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[CarMaintenance]  WITH CHECK ADD FOREIGN KEY([CarID])
REFERENCES [dbo].[Cars] ([CarID])
GO
ALTER TABLE [dbo].[CarMaintenance]  WITH CHECK ADD FOREIGN KEY([MaintenanceType])
REFERENCES [dbo].[MaintenanceTypes] ([TypeName])
GO
ALTER TABLE [dbo].[CarMaintenance]  WITH CHECK ADD FOREIGN KEY([MechanicID])
REFERENCES [dbo].[Mechanics] ([MechanicID])
GO
ALTER TABLE [dbo].[CarModels]  WITH CHECK ADD FOREIGN KEY([BrandID])
REFERENCES [dbo].[CarBrands] ([BrandID])
GO
ALTER TABLE [dbo].[Cars]  WITH CHECK ADD FOREIGN KEY([ModelID])
REFERENCES [dbo].[CarModels] ([ModelID])
GO
ALTER TABLE [dbo].[Cars]  WITH CHECK ADD FOREIGN KEY([OfficeID])
REFERENCES [dbo].[Offices] ([OfficeID])
GO
ALTER TABLE [dbo].[Cars]  WITH CHECK ADD FOREIGN KEY([StatusID])
REFERENCES [dbo].[CarStatus] ([StatusID])
GO
ALTER TABLE [dbo].[InsurancePolicies]  WITH CHECK ADD FOREIGN KEY([CarID])
REFERENCES [dbo].[Cars] ([CarID])
GO
ALTER TABLE [dbo].[Payments]  WITH CHECK ADD FOREIGN KEY([PaymentMethod])
REFERENCES [dbo].[PaymentMethods] ([MethodName])
GO
ALTER TABLE [dbo].[Payments]  WITH CHECK ADD FOREIGN KEY([RentalID])
REFERENCES [dbo].[Rentals] ([RentalID])
GO
ALTER TABLE [dbo].[Rentals]  WITH CHECK ADD FOREIGN KEY([CarID])
REFERENCES [dbo].[Cars] ([CarID])
GO
ALTER TABLE [dbo].[Rentals]  WITH CHECK ADD FOREIGN KEY([OfficeID])
REFERENCES [dbo].[Offices] ([OfficeID])
GO
ALTER TABLE [dbo].[Rentals]  WITH CHECK ADD FOREIGN KEY([UserID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[UserLogs]  WITH CHECK ADD FOREIGN KEY([UserID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[Users]  WITH CHECK ADD FOREIGN KEY([RoleID])
REFERENCES [dbo].[Roles] ([RoleID])
GO
/****** Object:  StoredProcedure [dbo].[sp_CreateCustomer]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_CreateCustomer]
    @FirstName NVARCHAR(100), @LastName NVARCHAR(100), @Email NVARCHAR(100), @Password NVARCHAR(50),
    @PhoneNumber NVARCHAR(20), @Address NVARCHAR(255), @LicenseNumber NVARCHAR(50),
    @UserID INT OUTPUT,
    @ErrorMessage NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @ErrorMessage = NULL;
    SET @UserID = NULL;
    
    BEGIN TRY
        -- Email kontrol� (case-insensitive ve trim)
        IF EXISTS (SELECT 1 FROM Users WHERE LOWER(LTRIM(RTRIM(Email))) = LOWER(LTRIM(RTRIM(@Email))))
        BEGIN
            SET @ErrorMessage = 'Bu email adresi zaten kullan�l�yor.';
            RETURN;
        END
        
        -- Ehliyet numaras� kontrol� (case-insensitive ve trim, NULL kontrol�)
        IF @LicenseNumber IS NOT NULL AND LEN(LTRIM(RTRIM(@LicenseNumber))) > 0
        BEGIN
            IF EXISTS (SELECT 1 FROM Users WHERE LicenseNumber IS NOT NULL 
                       AND LOWER(LTRIM(RTRIM(LicenseNumber))) = LOWER(LTRIM(RTRIM(@LicenseNumber))))
            BEGIN
                SET @ErrorMessage = 'Bu ehliyet numaras� zaten kay�tl�.';
                RETURN;
            END
        END
        
        -- Yeni m��teri ekle
        INSERT INTO Users (RoleID, FirstName, LastName, Email, PasswordHash, PhoneNumber, Address, LicenseNumber, IsActive, UpdatedAt)
        VALUES (2, @FirstName, @LastName, @Email, 'hashed_' + @Password, @PhoneNumber, @Address, @LicenseNumber, 1, GETDATE());
        
        SET @UserID = SCOPE_IDENTITY();
        
        -- Log kayd�
        INSERT INTO UserLogs (UserID, Action, IPAddress)
        VALUES (@UserID, 'Customer Created', 'Registration Panel');
        
    END TRY
    BEGIN CATCH
        SET @ErrorMessage = ERROR_MESSAGE();
    END CATCH
END
GO
/****** Object:  StoredProcedure [dbo].[sp_CreateRentalAgreement]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- D�ZELTME: sp_CreateRentalAgreement - Tarih �ak��ma Mant���
-- =============================================
CREATE PROCEDURE [dbo].[sp_CreateRentalAgreement]
    @UserID INT, @CarID INT, @OfficeID INT, @StartDate DATETIME, @EndDate DATETIME,
    @RentalID INT OUTPUT,
    @ErrorMessage NVARCHAR(500) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET @ErrorMessage = NULL;
    SET @RentalID = NULL;
    
    BEGIN TRY
        DECLARE @CurrentStatusID INT;
        SELECT @CurrentStatusID = StatusID FROM Cars WHERE CarID = @CarID;
        
        IF @CurrentStatusID != 1 
        BEGIN 
            SET @ErrorMessage = 'Ara� kiralama i�in uygun de�il (M�sait de�il).';
            RETURN;
        END
        
        -- D�ZELTME: Kapsaml� tarih �ak��ma kontrol�
        -- T�m �ak��ma durumlar�n� yakalar:
        -- 1. Yeni ba�lang��, mevcut kiralama aral��� i�inde
        -- 2. Yeni biti�, mevcut kiralama aral��� i�inde  
        -- 3. Mevcut kiralama, yeni aral�k i�inde (tamamen kapsan�yor)
        IF EXISTS (
            SELECT 1 FROM Rentals 
            WHERE CarID = @CarID 
            AND Status = 'Active' 
            AND (
                (@StartDate BETWEEN StartDate AND EndDate) 
                OR (@EndDate BETWEEN StartDate AND EndDate)
                OR (StartDate BETWEEN @StartDate AND @EndDate)
            )
        )
        BEGIN 
            SET @ErrorMessage = 'Ara� bu tarihlerde zaten kiralanm��.';
            RETURN;
        END
        
        BEGIN TRANSACTION
        
        DECLARE @TotalCost DECIMAL(10, 2) = dbo.fn_CalculateRentalTotal(@CarID, @StartDate, @EndDate);
        
        INSERT INTO Rentals (UserID, CarID, OfficeID, StartDate, EndDate, TotalCost, Status, UpdatedAt)
        VALUES (@UserID, @CarID, @OfficeID, @StartDate, @EndDate, @TotalCost, 'Active', GETDATE());
        
        SET @RentalID = SCOPE_IDENTITY();
        
        UPDATE Cars SET StatusID = 2, UpdatedAt = GETDATE() WHERE CarID = @CarID;
        
        COMMIT TRANSACTION
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        SET @ErrorMessage = ERROR_MESSAGE();
    END CATCH
END
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateCustomer]    Script Date: 15.12.2025 19:10:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateCustomer]
    @UserID INT, @FirstName NVARCHAR(100), @LastName NVARCHAR(100), @Email NVARCHAR(100),
    @PhoneNumber NVARCHAR(20), @Address NVARCHAR(255), @LicenseNumber NVARCHAR(50), @IsActive BIT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Users 
    SET FirstName = @FirstName, 
        LastName = @LastName, 
        Email = @Email, 
        PhoneNumber = @PhoneNumber, 
        Address = @Address, 
        LicenseNumber = @LicenseNumber, 
        IsActive = @IsActive, 
        UpdatedAt = GETDATE()
    WHERE UserID = @UserID;
END
GO
USE [master]
GO
ALTER DATABASE [CarRentalTrackingDB] SET  READ_WRITE 
GO